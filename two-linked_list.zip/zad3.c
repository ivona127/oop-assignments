/*3. 
Подобрете функцията на задача 2  int pop_middle(struct list_t* list, int* result), която:
- вместо да връща стойността на елемента я записва в указателя result
- ако списъкът е празен функцията връща резултат 0 и не записва нищо в result
- ако има елемент за изваждане връща резултат 1
*/

#include <stdio.h>
#include <stdlib.h>

struct node_t {
	int value;
	struct node_t* prev;
	struct node_t* next;
};

struct list_t {
	struct node_t* head;
	struct node_t* tail;
	int size;
	
};


void push_front(struct list_t* list, int value) {
  struct node_t* new_node = malloc(sizeof(struct node_t));
  new_node->value = value;

  new_node->prev = NULL;
  if(list->head != NULL) {
    list->head->prev = new_node;
  } else {
    list->tail = new_node;
  }
  new_node->next = list->head;

  list->head = new_node;

  list->size++;
}

int pop_middle (struct list_t* list, int* res) {
	struct node_t* tmp = list->head;
	int counter = 0;
	*res = 1;
	
	if(list->size==0){
		return 0;
	}
	
	if(list->size == 1){
		free(list->head);
		list->head = NULL;
    	list->tail = NULL;
		list->size--;
		return *res;
	}
	
	if(list->size == 2){
		list->head->next = NULL;
		list->tail = NULL;
		list->size--;
		return *res;
	}
	
	while (counter != list->size/2) {
		tmp= tmp->next;
		counter++;
	}
	
	tmp->prev->next = tmp->next;
	tmp->next->prev = tmp->prev;
	
	free(tmp);
	list->size--;
	
	return *res;
}

void print_list(struct list_t* list) {
  struct node_t* curr = list->head;
  int counter = 1;
  printf("size == %d\n", list->size);

  while(curr != NULL) {
    printf("[%d] %d\n", counter++, curr->value);
    curr = curr->next;
  }
}

int main () {
	struct list_t list = {NULL, NULL};
	int result = 0;	
	
	push_front(&list, 8);
	push_front(&list, 77);
 	push_front(&list, 103);
 	push_front(&list, 1);
 	
 	print_list(&list);
 	
 	puts("\n");
 	puts("\n");
 	
 	pop_middle(&list, &result);
 	printf("pop_middle - %d\n ", result);
}

