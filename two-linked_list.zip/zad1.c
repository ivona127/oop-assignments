/*
1.Дефинирайте функция void push_middle(struct list_t* list, int value), която:
- добавя нов елемент в средата на списъка
- ако броят елементи е нечетен (има среден елемент) новият елемент се поставя след средния
- ако списъкът има размер 0 или 1 функцията ще се държи като push_front
*/

#include <stdio.h>
#include<stdlib.h>

struct node_t {
  int value;
  struct node_t* next;
  struct node_t* prev;
};

struct list_t {
  struct node_t* head;
  struct node_t* tail;
  int size;
};

void push_front(struct list_t* list, int value) {
  struct node_t* new_node = malloc(sizeof(struct node_t));
  new_node->value = value;

  new_node->prev = NULL;
  if(list->head != NULL) {
    list->head->prev = new_node;
  } else {
    list->tail = new_node;
  }
  new_node->next = list->head;

  list->head = new_node;

  list->size++;
}

void insert_middle(struct list_t* list, int value) {
  struct node_t* new_node = malloc(sizeof(struct node_t));
  new_node->value = value;

  struct node_t* curr = list->head;
  int counter = 1;
  
  int size = 0;
  
  if(list->size % 2 !=0){
  	size = list->size/2 + 1;
  } else {
  	size = list->size/2;
  }
  
  while(counter != size) {
    curr = curr->next;
    counter++;
  }
  
  new_node->next = curr->next;

  curr->next->prev = new_node;
  curr->next = new_node;

  new_node->prev = curr;

  list->size++;
}

void print_list(struct list_t* list) {
  struct node_t* curr = list->head;
  int counter = 1;
  printf("size == %d\n", list->size);

  while(curr != NULL) {
    printf("[%d] %d\n", counter++, curr->value);
    curr = curr->next;
  }
}

int main() {
  struct list_t my_list = {NULL, NULL, 0};

  push_front(&my_list, 10);
  push_front(&my_list, 7);
  push_front(&my_list, 103);
  push_front(&my_list, 8);
  push_front(&my_list, 0);

  insert_middle(&my_list, 18);

  print_list(&my_list);

  return 0;
}

