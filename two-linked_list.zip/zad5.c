/*5. 
Имплементирайте структура от данни unrolled linked list (https://en.wikipedia.org/wiki/Unrolled_linked_list). Това е
разновидност на едно/двусвързан списък с една главна разлика - всеки елемент вместо една стойност съдържа масив от няколко стойности.
- в node_t вместо единичен член value използвайте масив от стойности с фиксиран размер 5 и допълнителен брояч за това колко от клетките в масива са заети
- при добавяне на нова стойност в списъка тя се поставя в масива на първия (push_front) или последния (push_back) елемент и се увеличава броячът му. Добавя се нов елемент node_t само ако масивът вече е запълнен
-имплементирайте функции push_front, push_back, poop_front, pop_back, sort_list
*/

#include <stdio.h>
#include <stdlib.h>

struct node_t {
  int data[5];
  int counter;
  struct node_t* prev;
  struct node_t* next;
};

struct list_t {
  struct node_t* head;
  struct node_t* tail;
};

void push_front(struct list_t* list, int value) {
	if (list->head->counter !=5){
		list->head->data[counter-1] = value;
		list->head->counter++;
		return;
	}	
	
 	struct node_t* new_node = malloc(sizeof(struct node_t));
 	new_node->value = value;

  new_node->prev = NULL;
  if(list->head != NULL) {
    list->head->prev = new_node;
  } else {
    list->tail = new_node;
  }
  new_node->next = list->head;

  list->head = new_node;

  list->size++;
}

void push_back(struct list_t* list, int value) {
	if (list->head->counter !=5){
		list->head->data[counter-1] = value;
		list->head->counter++;
		return;
	}	

  if(!list->head) {
    push_front(list, value);
    return;
  }

  struct node_t* new_node = malloc(sizeof(struct node_t));
  new_node->value = value;

  new_node->next = NULL;
  new_node->prev = list->tail;

  list->tail->next = new_node;
  list->tail = new_node;

  list->size++;
}

void print_list(struct list_t* list) {
  struct node_t* curr = list->head;
  int counter = 1;
  printf("size == %d\n", list->size);

  while(curr != NULL) {
    printf("[%d] %d\n", counter++, curr->value);
    curr = curr->next;
  }
}

void insert_middle(struct list_t* list, int value) {
  struct node_t* new_node = malloc(sizeof(struct node_t));
  new_node->value = value;

  struct node_t* curr = list->head;
  int counter = 1;

  while(counter < list->size / 2) {
    curr = curr->next;
    counter++;
  }
  //printf("%d %d\n", counter, curr->value);
  new_node->prev = curr;
  new_node->next = curr->next;

  curr->next->prev = new_node;
  curr->next = new_node;

  list->size++;
}

void pop_front(struct list_t* list) {
  if(!list->head) { // list->size == 0
    return;
  }

  if(!list->head->next) { // list->size == 1
    free(list->head);
    list->head = NULL;
    list->tail = NULL;
    list->size--;
    return;
  }

  list->head = list->head->next;
  free(list->head->prev);
  list->head->prev = NULL;
  list->size--;
}

void pop_back(struct list_t* list) {
  if(list->size < 2) {
    pop_front(list);
    return;
  }

  struct node_t* curr = list->tail;

  curr->prev->next = NULL;
  list->tail = curr->prev;
  free(curr);
  list->size--;
}



int main () {
	struct list_t list = {NULL, NULL};
	
}
