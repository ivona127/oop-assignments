/*
4. 
Като използвате едносвързан списък имплементирайте структура от данни опашка(queue):
има само методи push и pop елементите излизат в реда, в който са вкарани - push винаги добавя последен, а pop винаги вади първи
*/

#include <stdlib.h>
#include <stdio.h>

struct node_t {
  int data;
  struct node_t* next;
};

struct list_t {
  struct node_t* head;
  int size;
};

void insert(struct list_t* list, int value) {
  struct node_t* new_node = malloc(sizeof(struct node_t));

  new_node->data = value;

  new_node->next = list->head;
  list->head = new_node;
}

void remove_first(struct list_t* list) {
  if(list->head == NULL) {
    return;
  }

  struct node_t* old_head = list->head;
  list->head = old_head->next;
  free(old_head);
}


void insert_back(struct list_t* list, int value) {
  if(list->head == NULL) {
    insert(list, value);
    return;
  }

  struct node_t* last_node = list->head;

  while(last_node->next != NULL) {
    last_node = last_node->next;
  }

  struct node_t* new_node = malloc(sizeof(struct node_t));

  new_node->data = value;
  new_node->next = NULL;

  last_node->next = new_node;
}

void print_list(struct list_t* list) {
  if(!list->head) {
    puts("It's empty");
    return;
  }

  int i = 0;
  struct node_t* node = list->head;
  while(node!=NULL) {
    printf("[%d] %d\n", i++, node->data);
    node = node->next;
  }
}

int main () {
	struct list_t queue = {NULL};
	
	insert_back(&queue, 1);
	insert_back(&queue, 2);
	insert_back(&queue, 3);
	insert_back(&queue, 4);
	
	print_list(&queue);
	puts("\n");
	puts("\n");
	
	remove_first(&queue);
	remove_first(&queue);
	
	print_list(&queue);
	return 0;	
}
