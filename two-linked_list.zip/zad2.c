/*2.
Дефинирайте функция int pop_middle(struct list_t* list), която:
- намира елемента в средата на списъка, премахва го и връща неговата стойност като резултат
- ако броят на елементите е четен то вади и връща първия след средата
- ако елементите са само 1 или 2 то трябва да внимавате за правилното насочване на head и tail
*/

#include <stdio.h>
#include <stdlib.h>

struct node_t {
	int value;
	struct node_t* prev;
	struct node_t* next;
};

struct list_t {
	struct node_t* head;
	struct node_t* tail;
	int size;
};

void push_front(struct list_t* list, int value) {
  struct node_t* new_node = malloc(sizeof(struct node_t));
  new_node->value = value;

  new_node->prev = NULL;
  if(list->head != NULL) {
    list->head->prev = new_node;
  } else {
    list->tail = new_node;
  }
  new_node->next = list->head;

  list->head = new_node;

  list->size++;
}

int pop_middle (struct list_t* list) {
	struct node_t* tmp = list->head;
	int counter = 0;
	
	if(list->size == 1){
		int res = list->head->value;		//list->size = 1;
		free(list->head);
		list->head = NULL;
    	list->tail = NULL;
		list->size--;
		return res;
	}
	
	if(list->size == 2){
		int res = list->head->next->value;
		free(list->head->next);
		list->head->next = NULL;
		list->tail = NULL;
		list->size--;
		return res;
	}
	
	while (counter != list->size/2) {
		tmp= tmp->next;
		counter++;
	}
	
	tmp->prev->next = tmp->next;
	tmp->next->prev = tmp->prev;
	
	int res = tmp->value; 
	free(tmp);
	list->size--;
	
	return res;
}

void print_list(struct list_t* list) {
  struct node_t* curr = list->head;
  int counter = 1;
  printf("size == %d\n", list->size);

  while(curr != NULL) {
    printf("[%d] %d\n", counter++, curr->value);
    curr = curr->next;
  }
}

int main () {
	struct list_t list = {NULL, NULL};

	push_front(&list, 8);
	push_front(&list, 77);
// 	push_front(&list, 103);
// 	push_front(&list, 1);
 	
 	print_list(&list);
 	
 	puts("\n");
 	puts("\n");
 	
 	printf("pop_middle - %d\n ", pop_middle(&list));
}

